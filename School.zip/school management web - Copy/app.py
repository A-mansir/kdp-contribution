from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, FileField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from flask_wtf.file import FileAllowed
from flask_bcrypt import Bcrypt
from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import os
import secrets
from sqlalchemy.exc import IntegrityError
from flask import current_app
from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, DecimalField
from wtforms.validators import DataRequired, EqualTo, Email
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timedelta


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///school.db'
app.config['SQLALCHEMY_POOL_SIZE'] = 1000
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'AHMAD-SCHOOL-MANAGEMENT'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

class CustomUser(UserMixin):
    def __init__(self, user_id, username, password):
        self.id = user_id
        self.username = username
        self.password = password

# Initialize Flask app and Flask-Login
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Specify the login view route

@login_manager.user_loader
def load_user(username):
    return User.query.get(int(username))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False)
    bio_data = db.Column(db.Text, nullable=True)
    profile_picture = db.Column(db.String(255), nullable=True)

    __tablename__ = 'user'

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=20)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), Length(min=6)])
    bio_data = StringField ('Bio Data')
    profile_picture = FileField('Profile Picture', validators=[FileAllowed(['jpg', 'png', 'jpeg'], 'Images only!')])
    role = SelectField('Role', choices=[('student', 'Student'),('program', 'Program'), ('teacher', 'Teacher'), ('parent', 'Parent')],
                       validators=[DataRequired()])
    submit = SubmitField('Sign Up')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=20)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Login')

with app.app_context():
    db.create_all()

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(current_app.root_path, 'static/profile_pics', picture_fn)

    return picture_fn

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, password=hashed_password, role=form.role.data, bio_data=form.bio_data.data)

        # Save profile picture
        if form.profile_picture.data:
            picture_file = save_picture(form.profile_picture.data)
            user.profile_picture = picture_file

        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('login'))
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            flash('Login successful!', 'success')
            if user.role == 'staff':
                return redirect(url_for('staff'))
            elif user.role == 'student':
                return redirect(url_for('student'))
            elif user.role == 'program':
                return redirect(url_for('program'))
            elif user.role == 'parent':
                return redirect(url_for('parent'))
        else:
            flash('Login unsuccessful. Please check your username and password.', 'danger')
    return render_template("login.html", form=form)

@app.route("/contact", methods=["GET", "POST"])
def contact():
    return render_template("contact.html")

@app.route("/about", methods=["GET", "POST"])
def about():
    return render_template("about.html")

@app.route("/undergraduate", methods=["GET", "POST"])
def undergraduate():
    return render_template("undergraduate.html")

@app.route("/staff", methods=["GET", "POST"])
def staff():
    return render_template("staff_dashboard.html")

@app.route("/predegree", methods=["GET", "POST"])
def predegree():
    return render_template("predegree.html")

@app.route("/parent", methods=["GET", "POST"])
def parent():
    return render_template("parent_dashboard.html")

@app.route("/student", methods=["GET", "POST"])
def student():
    flash('Login successful!', 'success')
    return render_template("student_dashboard.html", user=current_user)

@app.route("/program", methods=["GET", "POST"])
def program():
    flash('Login successful!', 'success')
    return render_template("programs.html", user=current_user)

if __name__ == "__main__":
    db.init_app(app)
    with app.app_context():
        db.create_all()
    app.run(False)